
#include "rostek_localization/robot_localization.h"

using namespace std;
using namespace cartographer::mapping;

Map2Grid::~Map2Grid() {

        // Do something in here, free up used memory, print message, etc.

}

Map2Grid::Map2Grid(ros::NodeHandle &nh):
    nh_(nh),
    tf2_listener(tf2_buffer)
{
    map_sub_ = nh_.subscribe("map", 10, &Map2Grid::map_callback, this);
    scan_sub_ = nh_.subscribe("scan", 10, &Map2Grid::scan_callback, this);
    ROS_INFO("Created new Map2Grid Object.");
}

void Map2Grid::map_callback(const nav_msgs::OccupancyGrid::ConstPtr& occ_msg){
    //convert occupancy grid map to cartograph probability grid map struct

    int width, height;
    double offsetX, offsetY, offsetYaw;
    float resolution;


    resolution = occ_msg->info.resolution;
    width = occ_msg->info.width;
    height = occ_msg->info.height;
    offsetX = occ_msg->info.origin.position.x;
    offsetY = occ_msg->info.origin.position.y;
    float qw = occ_msg->info.origin.orientation.w;
    float qz = occ_msg->info.origin.orientation.z;
    float siny_cosp = 2 * qw * qz;
    float cosy_cosp = 1 - 2 * qz * qz;
    offsetYaw = std::atan2(siny_cosp, cosy_cosp);
    
    cartographer::mapping::ValueConversionTables conversion_tables;
    probability_grid = new ProbabilityGrid(
      MapLimits(resolution, Eigen::Vector2d(resolution*width, resolution*height), CellLimits(width, height)),
      &conversion_tables);
    auto convert_cell = [&, offsetX, offsetY, offsetYaw, width, height](int ind){
        Eigen::Array2i cell_index;
        cell_index[0] = ind/width; //y???
        cell_index[1] = ind%width; //x???
        // return cell_index(ind/width, ind%width);
        return cell_index;

    };
    for(int i; i < occ_msg->data.size(); i++)
    {
        auto cell_pos = convert_cell(i);
        int cell_value = occ_msg->data[i];
        if(cell_value == 100)
        {
            probability_grid->SetProbability(cell_pos, 1.0);
        }
        if(cell_value == 0)
        {
            probability_grid->SetProbability(cell_pos, 0.0);
        }
    }
}

cartographer::mapping::proto::ProbabilityGridRangeDataInserterOptions2D
CreateRangeDataInserterTestOptions2D() {
  auto parameter_dictionary = cartographer::common::MakeDictionary(R"text(
      return {
        insert_free_space = true,
        hit_probability = 0.7,
        miss_probability = 0.4,
      })text");
  return cartographer::mapping::CreateProbabilityGridRangeDataInserterOptions2D(
      parameter_dictionary.get());
}



void Map2Grid::scan_callback(const sensor_msgs::LaserScan::ConstPtr &scan_msg){
    tf2_Laser2Map = tf2_buffer.lookupTransform("map", scan_msg->header.frame_id, ros::Time(0));
    
    const auto translation = tf2_Laser2Map.transform.translation;
    const double yaw = tf::getYaw(tf2_Laser2Map.transform.rotation);

        const double half_FOV = (120.0/180.0)*M_PI; //120 degree each side


    const double angle_increment = scan_msg->angle_increment;
    const auto start = static_cast<int>(scan_msg->ranges.size()/2 - half_FOV/angle_increment);
    const auto end = static_cast<int>(scan_msg->ranges.size()/2 + half_FOV/angle_increment);
    double theta = scan_msg->angle_min + angle_increment*(start-1);

    for(int i=start; i<end; ++i)
    {
        theta+=angle_increment;

        if(std::isinf(scan_msg->ranges[i]) || std::isnan(scan_msg->ranges[i])) continue;

        // laser hit x, y in laser frame
        const double x_laser = scan_msg->ranges[i]*cos(theta);
        const double y_laser = scan_msg->ranges[i]*sin(theta);

        if(x_laser > look_ahead_distance || y_laser > look_ahead_distance) continue;

        // laser hit x, y in map frame
        const double x_map = x_laser*cos(yaw) - y_laser*sin(yaw) + translation.x;
        const double y_map = x_laser*sin(yaw) + y_laser*cos(yaw) + translation.y;


        point_cloud_laser.push_back({Eigen::Vector3f{x_map, y_map, 0.f}});

    }
    double x_tran, y_tran, yaw_tran;

    const cartographer::transform::Rigid2f expected_pose(
        {x_tran, y_tran}, yaw_tran);
    
    point_cloud_laser = cartographer::sensor::TransformPointCloud(
                point_cloud_laser, cartographer::transform::Embed3D(expected_pose.cast<float>()));
}

int main(int argc, char ** argv) {
    ros::init(argc, argv, "map2grid_node");
    ros::NodeHandle nh;
    Map2Grid obj(nh);
    ros::spin();
    return 0;
}