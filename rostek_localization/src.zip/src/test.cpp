// ros
#include <ros/ros.h>
//msgs
#include <sensor_msgs/LaserScan.h>
//nav
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/MapMetaData.h>
#include <nav_msgs/Odometry.h>
//tf
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include <tf2/LinearMath/Quaternion.h>
//geometry
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Quaternion.h>
// standard
#include <math.h>
#include <vector>
#include <array>
#include <string>
#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <boost/smart_ptr/shared_ptr.hpp>
#include "absl/memory/memory.h"

// cartographer
#include "cartographer/mapping/2d/probability_grid.h"
#include "cartographer/mapping/value_conversion_tables.h"
#include "cartographer/sensor/point_cloud.h"
#include "cartographer/sensor/range_data.h"
#include "cartographer/mapping/internal/2d/scan_matching/fast_correlative_scan_matcher_2d.h"
#include "cartographer/mapping/internal/2d/scan_matching/ceres_scan_matcher_2d.h"
#include "cartographer/mapping/internal/2d/scan_matching/real_time_correlative_scan_matcher_2d.h"
cartographer::mapping::ProbabilityGrid *probabilityGrid;
nav_msgs::MapMetaData mapMetaData;
cartographer::mapping::scan_matching::FastCorrelativeScanMatcher2D *fastCorrelativeScanMatcher2D;
cartographer::mapping::scan_matching::proto::FastCorrelativeScanMatcherOptions2D fastCorrelativeScanMatcherOptions2D;
bool haveMap = false;
bool first = true;
int limit_int, width, height;
float resolution;
std::array<float,3> origin; //0:x, 1:y, 2:yaw

void map_clbk(const nav_msgs::OccupancyGrid::ConstPtr& msg)
{
    mapMetaData = msg->info;
    cartographer::mapping::ValueConversionTables converisionTable;
    ROS_WARN("width: %i,height: %i", msg->info.width,msg->info.height);
    limit_int = ((msg->info.width > msg->info.height)? msg->info.width: msg->info.height);
    // limit_int = (li)
    // ROS_WARN
    resolution = msg->info.resolution;
    width = msg->info.width;
    height = msg->info.height;
    origin[0] = msg->info.origin.position.x;
    origin[1] = msg->info.origin.position.y;
    origin[2] = std::atan2(2*msg->info.origin.orientation.w*msg->info.origin.orientation.z, 1-2*msg->info.origin.orientation.z*msg->info.origin.orientation.z);
    probabilityGrid = new cartographer::mapping::ProbabilityGrid(cartographer::mapping::MapLimits(msg->info.resolution,
        Eigen::Vector2d(((double)limit_int)*resolution, ((double)limit_int)*resolution)
        , cartographer::mapping::CellLimits(limit_int*2, limit_int*2)),
        &converisionTable);
    // printf("%d", msg->data.size());

    for(int i=0; i < msg->data.size(); i++)
    {

        if (msg->data[i] == 100)
        {
            int x = limit_int - i/width - 1;
            int y = limit_int - i%width - 1;

            probabilityGrid->SetProbability({x,y}, 0.9);
        }
        else if (msg->data[i] == 0)
        {
            int x = limit_int - i/width - 1;
            int y = limit_int - i%width - 1;
            probabilityGrid->SetProbability({x,y}, 0.2);
        }
        
    }
    probabilityGrid->FinishUpdate();
    // probabilityGrid->ComputeCroppedGrid
    fastCorrelativeScanMatcher2D = new cartographer::mapping::scan_matching::FastCorrelativeScanMatcher2D(*probabilityGrid, fastCorrelativeScanMatcherOptions2D);
    haveMap = true;
}

void laser_clbk(const sensor_msgs::LaserScan::ConstPtr& msg)
{
    if (!haveMap) return;
    if (!first) return;
    first = false;
    float angleIncr = msg->angle_increment;
    float angleMin = msg->angle_min;
    cartographer::sensor::PointCloud pointClound;
    ROS_WARN("%d", msg->ranges.size());
    for(int i=0 ;  i < msg->ranges.size(); i++)
    {
        if (msg->ranges[i] > 5.0 || msg->ranges[i] < 0.2) continue;
        // ROS_WARN("%f, %f",std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i]);
        // pointClound.push_back({Eigen::Vector3f{std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i], 0.f}});
        pointClound.push_back({Eigen::Vector3f{std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i], 0.f}});

    }
    // cartographer::transform::Rigid2d expected_pose_double(
    //     {(+11.600000 -5.337),
    //     (10+12.288)},
    //     -1.5
    // );
    // cartographer::transform::Rigid2d expected_pose_double(
    //     {-11.600000,
    //     -10},
    //     -1.53
    // );
    // cartographer::transform::Rigid2d expected_pose_double(
    //     {14.65, 5.55},
    //     0.0
    // );
    // cartographer::transform::Rigid2d expected_pose_double(
    //     {11.587, 0.562},//{11.887, 1.362},//{11.137, 1.862},
    //     -4.5//-4.
    // );
    cartographer::transform::Rigid2d expected_pose_double(
        {14.55, 11.4},
        -0.
    );
    pointClound = cartographer::sensor::TransformPointCloud(pointClound, cartographer::transform::Embed3D(expected_pose_double.cast<float>()));
    cartographer::transform::Rigid2d pose_estimate;
    float score = 0.1;
    float min_score = 0.1;
    fastCorrelativeScanMatcher2D->Match(expected_pose_double, pointClound, min_score, &score, &pose_estimate);
    ROS_ERROR("score: %f",score);
    std::cout << "pose estimate: " << pose_estimate.DebugString() << std::endl;
    std::cout << "expected pose: " << expected_pose_double.DebugString() <<std::endl;
    first = true;
}

void laser_clbk1(const sensor_msgs::LaserScan::ConstPtr& msg)
{
    if (!first) return;
    first = false;
    float angleIncr = msg->angle_increment;
    float angleMin = msg->angle_min;
    cartographer::sensor::PointCloud pointClound;
    ROS_WARN("%d", msg->ranges.size());
    for(size_t i=0 ;  i < msg->ranges.size(); i++)
    {
        // ROS_WARN("%f, %f",std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i]);
        if ((msg->ranges[i]>5.0)||(msg->ranges[i]<0.3)) continue;
        pointClound.push_back({Eigen::Vector3f{std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i], 0.f}});
    }
}

int main (int argc, char **argv)
{
    ros::init(argc, argv, "test_fast");
    ros::NodeHandle n;
    fastCorrelativeScanMatcherOptions2D.set_linear_search_window(1.0);
    fastCorrelativeScanMatcherOptions2D.set_angular_search_window(6.5);
    fastCorrelativeScanMatcherOptions2D.set_branch_and_bound_depth(6);
    ros::Subscriber mapSub = n.subscribe("map", 1, &map_clbk);
    ros::Subscriber laserSub = n.subscribe("/scan", 1, &laser_clbk);
    ros::spin();
}



// // ros
// #include <ros/ros.h>
// //msgs
// #include <sensor_msgs/LaserScan.h>
// //nav
// #include <nav_msgs/OccupancyGrid.h>
// #include <nav_msgs/MapMetaData.h>
// #include <nav_msgs/Odometry.h>
// //tf
// #include <tf/transform_listener.h>
// #include <tf/transform_broadcaster.h>
// #include <tf2/LinearMath/Quaternion.h>
// //geometry
// #include <geometry_msgs/PoseWithCovarianceStamped.h>
// #include <geometry_msgs/PoseStamped.h>
// #include <geometry_msgs/Quaternion.h>
// // standard
// #include <math.h>
// #include <vector>
// #include <array>
// #include <string>
// #include <algorithm>
// #include <boost/algorithm/string.hpp>
// #include <boost/smart_ptr/shared_ptr.hpp>
// #include "absl/memory/memory.h"

// // cartographer
// #include "cartographer/mapping/2d/probability_grid.h"
// #include "cartographer/mapping/value_conversion_tables.h"
// #include "cartographer/sensor/point_cloud.h"
// #include "cartographer/sensor/range_data.h"
// #include "cartographer/mapping/internal/2d/scan_matching/fast_correlative_scan_matcher_2d.h"
// #include "cartographer/mapping/internal/2d/scan_matching/ceres_scan_matcher_2d.h"
// #include "cartographer/mapping/internal/2d/scan_matching/real_time_correlative_scan_matcher_2d.h"
// cartographer::mapping::ProbabilityGrid *probabilityGrid;
// nav_msgs::MapMetaData mapMetaData;
// cartographer::mapping::scan_matching::FastCorrelativeScanMatcher2D *fastCorrelativeScanMatcher2D;
// cartographer::mapping::scan_matching::proto::FastCorrelativeScanMatcherOptions2D fastCorrelativeScanMatcherOptions2D;
// bool haveMap = false;
// bool first = true;

// void map_clbk(const nav_msgs::OccupancyGrid::ConstPtr& msg)
// {
//     mapMetaData = msg->info;
//     cartographer::mapping::ValueConversionTables converisionTable;
//     ROS_WARN("%i, %i", msg->info.width,msg->info.height);
//     ROS_WARN("%f", ((double)msg->info.resolution)*msg->info.height);
//     double x_ = ((double)msg->info.resolution)*((double)msg->info.width);
//     double y_ = ((double)msg->info.resolution)*((double)msg->info.height);
//     probabilityGrid = new cartographer::mapping::ProbabilityGrid(cartographer::mapping::MapLimits(msg->info.resolution,
//         Eigen::Vector2d(x_, y_)
//         , cartographer::mapping::CellLimits(msg->info.width, msg->info.height)),
//         &converisionTable);
//     for(int i=0; i < msg->data.size(); i++)
//     {
//         if (msg->data[i] == 100) probabilityGrid->SetProbability(Eigen::Array2i(i%msg->info.width, i/msg->info.width), 0.9);
//         else if (msg->data[i] == 0) probabilityGrid->SetProbability(Eigen::Array2i(i%msg->info.width, i/msg->info.width), 0.1);
//         // if (msg->data[i] == 100) ROS_ERROR("%f", probabilityGrid->GetProbability(Eigen::Array2i{i%msg->info.width, i/msg->info.width}));
//         probabilityGrid->FinishUpdate();
//         // ROS_WARN("%d, %d", i%msg->info.width,i/msg->info.width);
//     }
//     // probabilityGrid->ComputeCroppedGrid
//     fastCorrelativeScanMatcher2D = new cartographer::mapping::scan_matching::FastCorrelativeScanMatcher2D(*probabilityGrid, fastCorrelativeScanMatcherOptions2D);
//     haveMap = true;
// }

// void laser_clbk(const sensor_msgs::LaserScan::ConstPtr& msg)
// {
//     if (!haveMap) return;
//     if (!first) return;
//     first = false;
//     float angleIncr = msg->angle_increment;
//     float angleMin = msg->angle_min;
//     cartographer::sensor::PointCloud pointClound;
//     ROS_WARN("%d", msg->ranges.size());
//     for(size_t i=0 ;  i < msg->ranges.size(); i++)
//     {
//         // ROS_WARN("%f, %f",std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i]);
//         pointClound.push_back({Eigen::Vector3f{std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i], 0.f}});
//     }
//     cartographer::transform::Rigid2d expected_pose_double(
//         {-11.600000 - -5.337,
//         -10-12.288},
//         -1.5
//     );
//     cartographer::transform::Rigid2d pose_estimate;
//     float score = 0.1;
//     float min_score = 0.1;
//     fastCorrelativeScanMatcher2D->Match(expected_pose_double, pointClound, min_score, &score, &pose_estimate);
//     ROS_ERROR("%f",score);
//     ROS_ERROR("f");
// }

// void laser_clbk1(const sensor_msgs::LaserScan::ConstPtr& msg)
// {
//     if (!first) return;
//     first = false;
//     float angleIncr = msg->angle_increment;
//     float angleMin = msg->angle_min;
//     cartographer::sensor::PointCloud pointClound;
//     ROS_WARN("%d", msg->ranges.size());
//     for(size_t i=0 ;  i < msg->ranges.size(); i++)
//     {
//         // ROS_WARN("%f, %f",std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i]);
//         pointClound.push_back({Eigen::Vector3f{std::cos(angleMin+angleIncr*i)*msg->ranges[i], std::sin(angleMin+angleIncr*i)*msg->ranges[i], 0.f}});
//     }
// }

// int main (int argc, char **argv)
// {
//     ros::init(argc, argv, "test_fast");
//     ros::NodeHandle n;
//     fastCorrelativeScanMatcherOptions2D.set_linear_search_window(20.0);
//     fastCorrelativeScanMatcherOptions2D.set_angular_search_window(1.);
//     fastCorrelativeScanMatcherOptions2D.set_branch_and_bound_depth(2);
//     ros::Subscriber mapSub = n.subscribe("map", 1, &map_clbk);
//     ros::Subscriber laserSub = n.subscribe("/scan", 1, &laser_clbk);
//     ros::spin();
// }