#include "cartographer/mapping/internal/2d/scan_matching/fast_correlative_scan_matcher_2d.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <random>
#include <string>

#include "cartographer/common/internal/testing/lua_parameter_dictionary_test_helpers.h"
#include "cartographer/mapping/2d/probability_grid.h"
#include "cartographer/mapping/2d/probability_grid_range_data_inserter_2d.h"
#include "cartographer/transform/rigid_transform_test_helpers.h"
#include "cartographer/transform/transform.h"
#include "gtest/gtest.h"


int main (int argc, char **argv)
{
    std::mt19937 prng(42);
    std::uniform_real_distribution<float> distribution(-1.f, 1.f);
    constexpr float kMinScore = 0.1f;
    cartographer::mapping::proto::ProbabilityGridRangeDataInserterOptions2D rangeOptions;
    rangeOptions.set_insert_free_space(true);
    rangeOptions.set_hit_probability(0.7);
    rangeOptions.set_miss_probability(0.4);
    cartographer::mapping::scan_matching::proto::FastCorrelativeScanMatcherOptions2D fastOptions;
    fastOptions.set_angular_search_window(1.0);
    fastOptions.set_linear_search_window(3.0);
    fastOptions.set_branch_and_bound_depth(3);
    cartographer::sensor::PointCloud point_cloud;
    // point_cloud.push_back({Eigen::Vector3f{0.f, 0.f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{1.f, 0.0f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{0.0f, -1.5, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{0.0f, -0.f, 0.f}});

    // point_cloud.push_back({Eigen::Vector3f{0.0f, -0.15, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{0.1f, 0.0, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{0.1f, -0.05, 0.f}});



    // point_cloud.push_back({Eigen::Vector3f{-5.0, 0.0, 0.f}});


    // point_cloud.push_back({Eigen::Vector3f{0.5f, 0.0f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{1.5f, 0.0f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{0.f, -0.75f, 0.f}});
    point_cloud.push_back({Eigen::Vector3f{0.f, 1.f, 0.f}});
    std::cout << point_cloud.size() << std::endl;
    // point_cloud.push_back({Eigen::Vector3f{6.f, 0.f, 0.f}});



    // point_cloud.push_back({Eigen::Vector3f{-1.f, 0.0f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{-0.5f, 0.0f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{-1.5f, 0.0f, 0.f}});
    


    // point_cloud.push_back({Eigen::Vector3f{0.f, -0.5f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{0.5f, -1.6f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{2.5f, 0.5f, 0.f}});
    // point_cloud.push_back({Eigen::Vector3f{2.5f, 1.7f, 0.f}});
    cartographer::mapping::ProbabilityGridRangeDataInserter2D range_data_inserter(rangeOptions);
    for (int i = 0; i != 1; ++i) {
        // const cartographer::transform::Rigid2f expected_pose(
        //     {2. * distribution(prng), 2. * distribution(prng)},
        //     0.5 * distribution(prng));
        const cartographer::transform::Rigid2f expected_pose(
            {0.0,0.0},
            0.0);

        cartographer::mapping::ValueConversionTables conversion_tables;
        cartographer::mapping::ProbabilityGrid probability_grid(
            cartographer::mapping::MapLimits(0.05, Eigen::Vector2d(672*0.05, 672*0.05), cartographer::mapping::CellLimits(672*2, 672*2)),
            // cartographer::mapping::MapLimits(0.05, Eigen::Vector2d(5.0, 5.0), cartographer::mapping::CellLimits(200, 200)),

            &conversion_tables);
        // probability_grid.SetProbability({78, 90}, 0.9);
        // probability_grid.SetProbability({0, 671}, 0.9);


        range_data_inserter.Insert(
            cartographer::sensor::RangeData{
                // Eigen::Vector3f(expected_pose.translation().x(),
                //                 expected_pose.translation().y(), 0.f),
                Eigen::Vector3f(0.,
                                0., 0.),
                cartographer::sensor::TransformPointCloud(
                    point_cloud, cartographer::transform::Embed3D(expected_pose.cast<float>())),
                {}},
            &probability_grid);
        // for (auto point: point_cloud)
        // {
        //     std::cout << point.position << "\n//"  << std::endl;
        // }
        //         point_cloud = cartographer::sensor::TransformPointCloud(
        //             point_cloud, cartographer::transform::Embed3D(expected_pose.cast<float>()));
        // std::cout << "############" << std::endl;
        // for (auto point: point_cloud)
        // {
        //     std::cout << point.position << "\n//" << std::endl;
        // }
        // probability_grid.SetProbability({150,80},1.0);
        // probability_grid.SetProbability({150,100},1.0);
        // probability_grid.SetProbability({180,100},1.0);

        // probability_grid.SetProbability({150,180},0.9);
        // probability_grid.SetProbability({150,130},0.9);



        probability_grid.FinishUpdate();
        probability_grid.SetProbability({1008, 1008}, 0.9);
        std::cout << "Result : " << std::endl;
        int sum = 0;
        for(int xi = 0; xi < 5000; xi++)
        {for (int yi = 0 ; yi < 5000; yi++) if(probability_grid.GetProbability({xi,yi}) >0.5) {std::cout << "test position " <<probability_grid.GetProbability({xi,yi}) << " " << xi << " , "<< yi << "\n";sum++;}}
        std::cout << "Sum : "<< sum <<std::endl;

        cartographer::mapping::scan_matching::FastCorrelativeScanMatcher2D fast_correlative_scan_matcher(probability_grid,
                                                                fastOptions);
        cartographer::transform::Rigid2d pose_estimate;
        float score;
        fast_correlative_scan_matcher.Match(
                cartographer::transform::Rigid2d::Identity(), point_cloud, kMinScore, &score,
                &pose_estimate);
        std::cout << "score: " << score << "\n";
        std::cout << "Actual: " << cartographer::transform::ToProto(pose_estimate).DebugString()
        << "\nExpected: " << cartographer::transform::ToProto(expected_pose).DebugString();
    }
    return 0;
}